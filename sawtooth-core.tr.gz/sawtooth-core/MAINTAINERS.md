| Name | GitHub | RocketChat |
| --- | --- | --- |
| Adam Ludvik | aludvik | adamludvik |
| Andi Gunderson | agunde406 | agunde |
| Anne Chenette | chenette | achenette |
| Boyd Johnson | boydjohnson | boydjohnson |
| Cian Montgomery | cianx | cianx |
| Dan Middleton | dcmiddle | Dan |
| Darian Plumb | dplumb94 | dplumb |
| James Mitchell | jsmitchell | jsmitchell |
| Jamie Jason | jjason | jjason |
| Nick Drozd | nick-drozd | drozd |
| Peter Schwarz | peterschwarz | pschwarz |
| Ryan Beck-Buysse | rbuysse | rbuysse |
| Shawn Amundson | vaporos | amundson |
| Zac Delventhal | delventhalz | zac |
